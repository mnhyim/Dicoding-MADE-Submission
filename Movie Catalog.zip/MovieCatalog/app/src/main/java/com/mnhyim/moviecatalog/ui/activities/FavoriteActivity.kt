package com.mnhyim.moviecatalog.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.mnhyim.moviecatalog.R
import com.mnhyim.moviecatalog.databinding.ActivityFavoriteBinding
import com.mnhyim.moviecatalog.ui.adapters.MoviesAdapter
import com.mnhyim.moviecatalog.ui.viewmodels.FavoriteViewModel
import com.mnhyim.moviecatalog.utils.Resource
import org.koin.android.ext.android.bind
import org.koin.androidx.viewmodel.ext.android.viewModel

class FavoriteActivity : AppCompatActivity() {

    private val TAG: String = this::class.java.simpleName
    private val favoriteViewModel: FavoriteViewModel by viewModel()
    private lateinit var binding: ActivityFavoriteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val moviesAdapter = MoviesAdapter()

        favoriteViewModel.movies.observe(this) {
            Log.d(TAG, "$it")
            if (it != null) {
                moviesAdapter.setMovies(it)
                binding.progressBar.visibility = View.INVISIBLE
            }
        }

        with(binding.rvMovies) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = moviesAdapter
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}