package com.mnhyim.moviecatalog.core.domain.repository

import com.mnhyim.moviecatalog.core.domain.model.Movie
import com.mnhyim.moviecatalog.utils.Resource
import kotlinx.coroutines.flow.Flow

interface CatalogRepositoryInterface {

    fun getAllMovies(): Flow<Resource<List<Movie>>>
    fun getAllFavoriteMovies(): Flow<List<Movie>>

    fun setFavoriteMovie(movie: Movie, status: Boolean)
}