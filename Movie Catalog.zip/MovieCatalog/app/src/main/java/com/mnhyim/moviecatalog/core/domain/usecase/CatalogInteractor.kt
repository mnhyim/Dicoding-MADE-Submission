package com.mnhyim.moviecatalog.core.domain.usecase

import com.mnhyim.moviecatalog.core.domain.model.Movie
import com.mnhyim.moviecatalog.core.domain.repository.CatalogRepositoryInterface
import com.mnhyim.moviecatalog.utils.Resource
import kotlinx.coroutines.flow.Flow

class CatalogInteractor(private val movieRepository: CatalogRepositoryInterface) : CatalogUseCase {
    override fun getAllMovies(): Flow<Resource<List<Movie>>> {
        return movieRepository.getAllMovies()
    }

    override fun getAllFavoriteMovies(): Flow<List<Movie>> {
        return movieRepository.getAllFavoriteMovies()
    }

    override fun setFavoriteMovie(movie: Movie, status: Boolean) {
        return movieRepository.setFavoriteMovie(movie, status)
    }
}