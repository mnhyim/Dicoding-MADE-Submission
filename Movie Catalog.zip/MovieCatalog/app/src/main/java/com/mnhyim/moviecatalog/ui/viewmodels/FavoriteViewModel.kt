package com.mnhyim.moviecatalog.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.mnhyim.moviecatalog.core.domain.usecase.CatalogUseCase

class FavoriteViewModel(private val catalogUseCase: CatalogUseCase) : ViewModel()  {

    val movies = catalogUseCase.getAllFavoriteMovies().asLiveData()
}