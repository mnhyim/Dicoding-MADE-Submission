package com.mnhyim.moviecatalog.ui.viewmodels

import androidx.lifecycle.ViewModel
import com.mnhyim.moviecatalog.core.domain.usecase.CatalogUseCase
import androidx.lifecycle.asLiveData

class CatalogViewModel(private val catalogUseCase: CatalogUseCase) : ViewModel() {

    val movies = catalogUseCase.getAllMovies().asLiveData()
}